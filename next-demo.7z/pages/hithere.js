function HiThere() {
  return (
    <>
      <p style={{ color: 'red' }}>hi there</p>
      <img src="/my-image.png" alt="my image" />
    </>
  )
}
export default HiThere