function HelloWorld() {
  return (
    <div>
      <p>Hello world</p>
      <p>scoped!</p>
      <style jsx>{`
        p {
          color: blue;
        }
        div{
          background: red;
        }
        @media (max-width: 600px) {
          div {
            background: blue;
          }
        }
      `}</style>
      <style global jsx>{`
        body {
          background: black;
        }
      `}</style>
    </div>
  )
}

export default HelloWorld