import Header from '../components/Header'

const Contact = () => (
  <div>
    <Header />
    <p>This is the contact page.</p>
  </div>
)

export default Contact
