import React from 'react'

export default () => <div>b</div>
