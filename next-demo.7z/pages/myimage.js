function MyImage(){
    return <img src="/my-image.png" alt="my image" />
}
export default MyImage