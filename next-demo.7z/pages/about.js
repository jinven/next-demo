function About(){
    return <h1>关于页面</h1>
}
About.getInitialProps = async () => {
    return {}
  }
export default About