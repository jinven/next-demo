'use strict';

var PLANE = {}
function ShaderPlane() {
  this.prototype = {};
  var _this = this;
  //f_shader6.txtは使用していない
  GL_CORE.vertexShaders = [];
  GL_CORE.fragmentShaders = [];
  GL_CORE2.vertexShaders = [];
  GL_CORE2.fragmentShaders = [];
  var vertexshader, fragmentshader;
  var vertexShaderLoadCount = 0;
  var fragmentShaderLoadCount = 0;
  PLANE.colorShift = 0;
  PLANE.material2HBS_Xshift = 0;
  var addedInitFunc;
  var initEnd;
  this.initEnd;
  loadShaderText(0, 0);
  function loadShaderText(l, i) {
    var textUrl = "/datas/txts/shader.txt";
    $.ajax({
      type: "GET",
      dataType: "xml",//dataTypeを指定する
      url: textUrl,
      success: function (data) {
        GL_CORE.vertexShaders.push($("#core_vertexShader1", $(data)).text());
        GL_CORE.vertexShaders.push($("#core_vertexShader2", $(data)).text());
        GL_CORE2.vertexShaders.push($("#core_vertexShader1", $(data)).text());
        GL_CORE2.vertexShaders.push($("#core_vertexShader2", $(data)).text());
        GL_CORE2.vertexShaders.push($("#core_vertexShader3", $(data)).text());
        for (var n = 1; n <= 6; n++) {
          GL_CORE.fragmentShaders.push($("#core_fragmentShader" + n, $(data)).text());
          GL_CORE2.fragmentShaders.push($("#core2_fragmentShader" + n, $(data)).text());
        }
        BALL.vertexShader2 = $("#ball_vertexShader1", $(data)).text();
        BALL.vertexShader3 = $("#ball_vertexShader2", $(data)).text();
        BALL.fragmentShader2 = $("#ball_fragmentShader1", $(data)).text();
        BALL.fragmentShader3 = $("#ball_fragmentShader2", $(data)).text();
        PLANE.planeVertexShader = $("#plane_vertexShader", $(data)).text();
        PLANE.planeFragmentShader = $("#plane_fragmentShader", $(data)).text();
        initFunc();
        initEnd = true;
        _this.initEnd = true;
      }
    });
  }
  var shadersRender;
  var shadersUpdateDivergence;//発散
  var shadersUpdatePressure;
  var shadersUpdateVelocity;
  var shadersAdvectData;
  var startTime, pastTime;
  GL_CORE.pastTime;
  GL_CORE.resizeHl;
  GL_CORE.aspect = 1;
  var plane;
  var planeGeometry;
  var planeMaterial;
  PLANE.centerPoint = new THREE.Vector2();
  var plane2, planeGeometry2, planeMaterial2;
  var RTT;
  var RTTgeometry, RTTmaterial, RTTmesh;
  var RTTcamera;
  var RTTscene;
  var imgTextur;
  var glCore;
  var ball;
  var moveGLMouseP;
  var testMesh;
  var planePaints = [];
  function initFunc() {
    glCore = new GlCore();
    glCore.init();
    startTime = new Date().getTime();
    plane = GL_CORE.mesh;
    planeGeometry2 = new THREE.PlaneBufferGeometry(100, 100);
    planeMaterial2 = new THREE.ShaderMaterial({
      uniforms: {
        'time': {
          type: 'f',
          value: 0
        },
        'colorShift': {
          type: 'f',
          value: 0
        },
        'ascpect': {
          type: 'f',
          value: 1
        },
        'positions': {
          type: 'v2',
          value: [new THREE.Vector2(0.5, 0.5), new THREE.Vector2(0.5, 0.5), new THREE.Vector2(0.5, 0.5)]
        },
        'gradRatio': {
          type: 'f',
          value: 0
        },
        'HBS_Xshift': {
          type: 'f',
          value: 0
        },
        'radiuses': {
          type: 'f',
          value: [0, 0, 0]
        },
        'opacity': {
          type: 'f',
          value: 0.5
        },
        'colors': {
          type: 'v3',
          value: [new THREE.Color(1, 0.5, 0.5), new THREE.Color(1, 0.5, 0.5), new THREE.Color(1, 0.5, 0.5)]
        }
      }, vertexShader: PLANE.planeVertexShader,
      fragmentShader: PLANE.planeFragmentShader,
      transparent: true
    });
    plane2 = new THREE.Mesh(planeGeometry2, planeMaterial2);
    plane2.position.z = 100;
    plane2.receiveShadow = true;
    plane.receiveShadow = true;
    MAIN.stage.add(plane2);
    ball = new Ball();
    //最初、マウスポイントはセンター(仮)
    //実際は最初のresizeHlでball.initPositio時に設定される
    setTimeout(function () {
      PLANE.realMouseP.set(MAIN.canvasW / 2, MAIN.canvasH / 2);
    }, 500)
    for (var n = 0; n < 1; n++) {
      var planePaint = new PlanePaint();
      planePaints.push(planePaint);
    }
    moveGLMouseP = new MoveGLMouseP();
    initEnd = true;
    addedInitFunc();
  }
  PLANE.mouseP = new THREE.Vector2(0.5, 0.5);
  GL_CORE.mouseP = new THREE.Vector2();
  PLANE.uvMouseP = new THREE.Vector2(-1, -1);
  PLANE.lastMouseP = PLANE.mouseP.clone();
  PLANE.centerP = new THREE.Vector2(0.5, 0.5);
  var over = new THREE.Vector2();
  var verticalState;
  GL_CORE.resizeHl = function () { };
  var inertiaPoint;
  this.addInitFunc = function (func) {
    addedInitFunc = func;
  }
  this.getShaderObject = function () {
    //PLANE.realMouseP=new THREE.Vector2(0,0);
    return { material: planeMaterial, mesh: plane };
  }
  PLANE.realMouseP = new THREE.Vector2(MAIN.canvasW / 2, MAIN.canvasH / 2);
  PLANE.targetCenterRatio = new THREE.Vector2(0.1, -0.15)
  PLANE.realMouseP = new THREE.Vector2(MAIN.canvasW / 2 + MAIN.canvasW * PLANE.targetCenterRatio.x, MAIN.canvasH / 2 + MAIN.canvasH * PLANE.targetCenterRatio.y);
  /////////////////////////
  //
  //this.mouseMoveHl
  //
  /////////////////////////
  var mouseMoveStateTimer = setTimeout(function () { }, 10);
  var mouseMoveState = false;
  var mousePRatio = new THREE.Vector2();
  this.mouseMoveHl = function (p) {
    mouseMoveState = true;
    clearTimeout(mouseMoveStateTimer);
    mouseMoveStateTimer = setTimeout(function () {
      mouseMoveState = false;
    }, 1000);
    PLANE.realMouseP.copy(p);
    if (verticalState) {
      mousePRatio.x = (p.x + over.x) / MAIN.canvasW;
      mousePRatio.y = (MAIN.canvasH - (p.y)) / MAIN.canvasH;
    } else {
      mousePRatio.x = (p.x) / MAIN.canvasW;
      mousePRatio.y = (MAIN.canvasH - (p.y)) / MAIN.canvasH;
    }
    PLANE.mouseP.x = autoMoveP.x + mousePRatio.x;
    PLANE.mouseP.y = autoMoveP.y + mousePRatio.y;
    PLANE.uvMouseP.set(PLANE.mouseP.x, PLANE.mouseP.y);
    if (ball) {
      ball.mouseMoveHl(PLANE.realMouseP);
    }
    PLANE.lastMouseP.copy(PLANE.mouseP);
  }
  var ratioW;
  this.resizeHl = function (canvasW, canvasH) {
    ratioW = canvasW / canvasH;
    var viewRatio = 1;
    planeMaterial2.uniforms.ascpect.value = ratioW;
    if (ratioW > 1) {
      plane.scale.set(viewRatio * canvasW / 100, viewRatio * canvasH / 100, 1);
      plane2.scale.set(viewRatio * canvasW / 100, viewRatio * canvasH / 100, 1);
      over.x = 0;
      over.y = (canvasW - canvasH) / 2;
      verticalState = false;
      PLANE.targetCenterRatio = new THREE.Vector2(0.15, -0.15);
    } else {
      plane.scale.set(viewRatio * canvasW / 100, viewRatio * canvasH / 100, 1);
      plane2.scale.set(viewRatio * canvasW / 100, viewRatio * canvasH / 100, 1);
      over.x = (canvasH - canvasW) / 2;
      over.y = 0;
      verticalState = true;
      PLANE.targetCenterRatio = new THREE.Vector2(0.1, -0.15)
    }
    if (initEnd) {
      GL_CORE.resizeHl(canvasW, canvasH);
      GL_CORE.aspect = ratioW;
    }
    if (ball) {
      if (!ball.initEnd) {
        ball.initPosition();
      }
      ball.resizeHl(canvasW, canvasH);
    }
    if (moveGLMouseP) {
      moveGLMouseP.resizeHl(canvasH, ratioW);
    }
  }
  var PlanePaintID = 0;
  var colorShiftRatio = 1;
  function PlanePaint() {
    var radius1Interval = Math.random() * 100;
    radius1Interval = 0;
    var radius1IntervalCount = 0;
    var radius1Count = 0;
    var radius1CountMax = 200;
    var radiusCountState;
    var colorHSL;
    var remainL;
    var id = PlanePaintID;
    PlanePaintID += 1;
    var lightPosition = new THREE.Vector2();
    var colorShift = 0;
    this.update = function () {
      if (colorShiftState) {
        if (colorShiftRatio < 1) {
          colorShiftRatio += 0.01;
        } else if (colorShiftRatio > 1) {
          colorShiftRatio = 1;
        }
      } else {
        if (colorShiftRatio != 0) {
          colorShiftRatio -= 0.01;
          if (colorShiftRatio < 0.001) {
            colorShiftRatio = 0;
            startTime = new Date().getTime();
          }
        }
      }
      BALL.colorShiftRatio = colorShiftRatio;
      colorShift = colorShiftRatio * (Math.sin(Math.PI * GL_CORE.pastTime * 0.00002 % (Math.PI * 0.5)));
      GL_CORE.uMonocromeRatio = colorShiftRatio;
      //全体のカラーシフト
      PLANE.colorShift = colorShift;
      planeMaterial2.uniforms.opacity.value = 0.5 - (1 - colorShiftRatio) * 0.25;
      planeMaterial2.uniforms.colorShift.value = Math.pow(colorShiftRatio, 2.5);
      planeMaterial2.uniforms.gradRatio.value = 1 - colorShiftRatio;
      planeMaterial2.uniforms.HBS_Xshift.value = PLANE.material2HBS_Xshift;
      if (!radiusCountState) {
        if (radius1IntervalCount > radius1Interval) {
          radiusCountState = true;
          radius1Count = 0;
          var newColor = new THREE.Color(0.7, 0.1, 0.1);
          //左影のカラー
          newColor.offsetHSL(0.0, 0, 0);
          colorHSL = newColor.getHSL();
          remainL = 1 - colorHSL.l;
          planeMaterial2.uniforms.colors.value[id] = newColor;
          planeMaterial2.uniforms.radiuses.value[id] = 0;
          planeMaterial2.uniforms.positions.value[id] = new THREE.Vector2(0.5, 0.5);
        }
        radius1IntervalCount += 1;
      } else {
        var radiuse1Ratio = radius1Count / radius1CountMax;
        radiuse1Ratio = 0.3;
        if (radiuse1Ratio <= 1) {
          planeMaterial2.uniforms.radiuses.value[id] = 1.5 * radiuse1Ratio;
          var colorRatio = Math.pow(Math.abs(Math.cos(Math.PI * radiuse1Ratio)), 2.5);
          planeMaterial2.uniforms.colors.value[id].setHSL(colorHSL.h, colorHSL.s, colorHSL.l + remainL * colorRatio);
          lightPosition.x = 0.8 * ratioW * (BALL.container.position.x / MAIN.canvasW + 0.5);
          lightPosition.y = 1.15 * (BALL.container.position.y / MAIN.canvasH + 0.5);
          planeMaterial2.uniforms.positions.value[id].copy(lightPosition);
        } else {
          radiusCountState = false;
          radius1IntervalCount = 0;
        }
        radius1Count += 1;
      }
    }
  }
  var autoMoveP = new THREE.Vector2(0, 0);
  function MoveGLMouseP() {
    this.prototype = {};
    var Radius = 0;
    var RadiusCount = 0;
    var RadiusCountMax = 50 + Math.random() * 100;
    var RadiusMax = 0.35;
    var Rotation = 0;
    var RotationDir = 1;
    var RotationSpeed = 0.01;
    var startRadiuse, difRadius;
    this.resizeHl = function (h, accept) {
    }
    this.update = function () {
      if (Radius != 0) {
        Rotation += RotationSpeed;
        autoMoveP.x = Radius * Math.cos(Rotation);
        autoMoveP.y = Radius * Math.sin(Rotation);
        RotationSpeed = (Math.random < 0.5) ? 0.01 : -0.01;
      }
      if (!mouseMoveState) {
        if (RadiusCount == 0) {
          startRadiuse = autoMoveP.length();
          difRadius = RadiusMax - startRadiuse;
        }
        if (RadiusCount >= 0 && RadiusCount <= RadiusCountMax) {
          var ratio = RadiusCount / RadiusCountMax;
          Radius = startRadiuse + difRadius * ratio;
        } else {
          RotationDir *= -1;
          RadiusCountMax = 50 + Math.random() * 150;
        }
        RadiusCount += RotationDir;
        PLANE.mouseP.x = autoMoveP.x + mousePRatio.x;
        PLANE.mouseP.y = autoMoveP.y + mousePRatio.y;
        PLANE.uvMouseP.set(PLANE.mouseP.x, PLANE.mouseP.y);
        PLANE.lastMouseP.copy(PLANE.mouseP);
      } else {
        if (Math.abs(autoMoveP.x) + Math.abs(autoMoveP.y) > 0.001) {
          autoMoveP.multiplyScalar(0.9);
        } else {
          autoMoveP.set(0, 0);
        }
        Radius = autoMoveP.length();
        if (RadiusCount != 0) {
          RadiusCount = 0;
        }
      }
    }
  }
  var colorShiftState = true;;
  this.startColorShift = function () {
    colorShiftState = true;
  }
  this.stopColorShift = function () {
    colorShiftState = false;
  }
  var updateCount = 0;
  this.update = function () {
    if (initEnd) {
      updateCount += 1;
      GL_CORE.pastTime = pastTime = new Date().getTime() - startTime;
      for (var n = 0; n < planePaints.length; n++) {
        planePaints[n].update();
      }
      planeMaterial2.needsUpdate = true;
      if (ball) {
        ball.update();
      }
      GL_CORE.shaderUpdate();
      if (moveGLMouseP) {
        moveGLMouseP.update();
      }
    }
  }
}
