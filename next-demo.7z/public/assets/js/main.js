var MAIN={};
MAIN.burgerShow;


(function(MAIN){
    //common main.js
    MAIN.winW,MAIN.winH;
	var win;
    var threeBase;
    var scrollEnabled;
	
    MAIN.shaderPlane;
        
    $(function(){
        utils.init();
        //utils.setTraceBox();
		win=$(window);
        
        if(utils.os=="windows" && utils.Browser=="edge"){
            MAIN.edge=true;
            $("body").addClass("edge");
        }
        
        threeBase=new ThreeBase();
        
        shaderPlane=new ShaderPlane();
        MAIN.shaderPlane=shaderPlane;
        
        shaderPlane.addInitFunc(initFunc);
        
        var location=String(window.location.href).replace(/http:\/\/|https:\/\//,"").split("/");
        
        var referrer=String(document.referrer).replace(/http:\/\/|https:\/\//,"").split("/");
        
        var domein=location[0];
        
        var currentLocation=String(window.location.href).replace(/http:\/\/|https:\/\//,"").replace(location[0],"");
        
        function initFunc(){
            //在shaderPlane着色器读入后初期化
            threeBase.addResizeHl(MAIN.resizeHl);
            threeBase.addUpdateHl(MAIN.update);
            threeBase.addMouseMoveHl(MAIN.mouseMoveHl);

            setTimeout(function(){
                planeObject=shaderPlane.getShaderObject();
            },100);
            
            planeObject=shaderPlane.getShaderObject();
         
            showLogo();
                        
        }
          
		//渲染球
 		function showLogo(){
            var alphabet=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];

            var changeCount;
            var lastChangeCount=4;
            var interval=4;
            var rollingTextsSet=[];
            var textCount=0;
            var rollTextCount=0;
            
            rollText();

            function rollText(){
                var targetText="";
                var completeNum=0;
                rollTextCount+=1;
                if(rollTextCount%interval==0){
                    textCount+=1;
                }
                for(var n=0;n<textCount;n++){
                    targetTextObj=rollingTextsSet[n];
                    targetText+=targetTextObj.update();
                    if(targetTextObj.complete){
                        completeNum+=1;
                    }
                }
                setTimeout(function(){
                     threeBase.init();
                	$("#three_area").addClass("show");
                    win.bind("scroll",MAIN.scrollHl);
                    scrollEnabled=true;
                },100)
            }

            function RollingText(id,texts,maxNum){
                this.prototype={};
                this.complete=false;
                this.textCount=0;

                this.update=function(){
                    var currentCount=this.textCount;
                    if(!this.complete){
                      
                        if(this.textCount>=maxNum-1){
                            this.complete=true;
                        }else{
                            this.textCount+=1;
                        }
                    }
                   return texts[currentCount];
                }
            }
        }
        
    });
    
    MAIN.mouseMoveHl=function(p){
        if(shaderPlane.initEnd){
            shaderPlane.mouseMoveHl(p);
        }
    }
	
	MAIN.resizeHl=function(winW,winH,canvasW,canvasH){
       
		if(win){
			MAIN.winW=winW;
			MAIN.winH=winH;
			MAIN.canvasW=canvasW;
			MAIN.canvasH=canvasH;
           
            if(shaderPlane){
               shaderPlane.resizeHl(canvasW,canvasH);
            }
		}
        
        MAIN.scrollHl();
	}
    
    MAIN.mouseWheelHl=function(e){
        
    }
	
	MAIN.scrollHl=function(){
       
        if(win.scrollTop()>MAIN.winH && scrollEnabled){
            THREE.noRender=true;
        }else{
            THREE.noRender=false;
        }
		
		
	}
	
	MAIN.update=function(){
        shaderPlane.update();
	}
    
    MAIN.changeServiceColor=function(){
        if(MAIN.shaderPlane){
            MAIN.shaderPlane.stopColorShift();
        }
    }
    
    MAIN.stopServiceColor=function(){
        if(MAIN.shaderPlane){
            MAIN.shaderPlane.startColorShift();
        }
    }
	
    jQuery.extend( jQuery.easing,
{
	def: 'easeOutQuad',
	swing: function (x, t, b, c, d) {
		
		return jQuery.easing[jQuery.easing.def](x, t, b, c, d);
	},
	easeInQuad: function (x, t, b, c, d) {
		return c*(t/=d)*t + b;
	},
	easeOutQuad: function (x, t, b, c, d) {
		return -c *(t/=d)*(t-2) + b;
	},
	easeInOutQuad: function (x, t, b, c, d) {
		if ((t/=d/2) < 1) return c/2*t*t + b;
		return -c/2 * ((--t)*(t-2) - 1) + b;
	},
	easeInCubic: function (x, t, b, c, d) {
		return c*(t/=d)*t*t + b;
	},
	easeOutCubic: function (x, t, b, c, d) {
		return c*((t=t/d-1)*t*t + 1) + b;
	},
	easeInOutCubic: function (x, t, b, c, d) {
		if ((t/=d/2) < 1) return c/2*t*t*t + b;
		return c/2*((t-=2)*t*t + 2) + b;
	},
	easeInQuart: function (x, t, b, c, d) {
		return c*(t/=d)*t*t*t + b;
	},
	easeOutQuart: function (x, t, b, c, d) {
		return -c * ((t=t/d-1)*t*t*t - 1) + b;
	},
	easeInOutQuart: function (x, t, b, c, d) {
		if ((t/=d/2) < 1) return c/2*t*t*t*t + b;
		return -c/2 * ((t-=2)*t*t*t - 2) + b;
	},
	easeInQuint: function (x, t, b, c, d) {
		return c*(t/=d)*t*t*t*t + b;
	},
	easeOutQuint: function (x, t, b, c, d) {
		return c*((t=t/d-1)*t*t*t*t + 1) + b;
	},
	easeInOutQuint: function (x, t, b, c, d) {
		if ((t/=d/2) < 1) return c/2*t*t*t*t*t + b;
		return c/2*((t-=2)*t*t*t*t + 2) + b;
	},
	easeInSine: function (x, t, b, c, d) {
		return -c * Math.cos(t/d * (Math.PI/2)) + c + b;
	},
	easeOutSine: function (x, t, b, c, d) {
		return c * Math.sin(t/d * (Math.PI/2)) + b;
	},
	easeInOutSine: function (x, t, b, c, d) {
		return -c/2 * (Math.cos(Math.PI*t/d) - 1) + b;
	},
	easeInExpo: function (x, t, b, c, d) {
		return (t==0) ? b : c * Math.pow(2, 10 * (t/d - 1)) + b;
	},
	easeOutExpo: function (x, t, b, c, d) {
		return (t==d) ? b+c : c * (-Math.pow(2, -10 * t/d) + 1) + b;
	},
	easeInOutExpo: function (x, t, b, c, d) {
		if (t==0) return b;
		if (t==d) return b+c;
		if ((t/=d/2) < 1) return c/2 * Math.pow(2, 10 * (t - 1)) + b;
		return c/2 * (-Math.pow(2, -10 * --t) + 2) + b;
	}
});
    
    
    
})(MAIN);
