"use strict";
function ThreeBase() {
  this.property = {};
  var renderer;
  var _this = this;
  var Detector = {
    webgl: (function () {
      try {
        renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
        return true;
      } catch (e) {
        if (utils.Browser == "ie9") {
          renderer = new THREE.CanvasRenderer();
        } else {
          renderer = new THREE.CanvasRenderer({ antialias: false, alpha: false });
        }
        MAIN.canvasRenderer = true;
        return false;
      }
    })()
  };
  if (!Detector.webgl) {
    //WebGl非対応分岐
    alert("このコンテンンツは webGLを使用しています。\nwebGLレンダリングでエラーが出ています。\n対応した最新のブラウザでごらんください。");
    //$("#main nav").addClass("show");
    //$("#main .preloader").remove();
    return;
  }
  if (utils.Browser == "ie11") {
    var alert = $("<div>お使いのブラウザでは正常に表示することができません。<br>その他のブラウザをご使用下さい。</div>");
    alert.css({
      "position": "fixed",
      "z-index": 10000,
      "top": "50%",
      "left": "50%",
      "transform": "translate(-50%,-50%)",
      "padding": "2em",
      "font-size": "1.6em",
      "font-weight": "bold",
      "background-color": "rgba(255,255,255,0.6)"
    })
    $("body").append(alert);
    $("#three_area").css("visibility", "hidden");
    $(".center_area").css("visibility", "hidden");
    $("header").css("visibility", "hidden");
    $("header .logo").css("visibility", "visible");
    $(".sns").css("visibility", "hidden");
    $(".copyright,h2").css("visibility", "hidden");
  }
  /////////////////////////////
  //
  //threeの初期設定
  //
  ////////////////////////////
  var winW, winH;
  var win;
  var initEnd;
  var canvasW, canvasH;
  var canvas;
  var threeCanvasArea;
  var scene;
  //var renderer;
  var rotateStage = new THREE.Object3D();
  var moveStage = new THREE.Object3D();
  //camera
  var camera;
  var fov = 30;//レンズの口径(deg)
  var aspect;
  var near = 15;
  var far = 100000;
  var firstZ = 200;
  win = $(window);
  threeCanvasArea = $("#three_area");
  MAIN.canvasArea = threeCanvasArea;
  scene = new THREE.Scene();
  win.resize(resizeHl);
  resizeHl();
  aspect = winW / winH;
  camera = new THREE.PerspectiveCamera(fov, aspect, near, far);
  camera.position.set(0, 0, firstZ);
  camera.zoom = 1;
  MAIN.camera = camera;
  MAIN.renderer = renderer;
  scene.add(camera);
  //ライト(2種)
  var light1 = new THREE.DirectionalLight(0xffffff, 1);
  light1.lookAt(new THREE.Vector3(0, 0, 0));
  light1.position.set(1, 1, 1);
  light1.position.set(250, 250, 500);
  light1.shadow.camera.left = -1000;
  light1.shadow.camera.right = 1000;
  light1.shadow.camera.top = -1000;
  light1.shadow.camera.bottom = 1000;
  light1.shadow.camera.near = 10;
  light1.shadow.camera.far = 10000;
  light1.shadow.mapSize.x = 2048;
  light1.shadow.mapSize.y = 2048;
  var light2 = new THREE.SpotLight(0xffffff, 1, 0, Math.PI / 3, 0.5, 1);
  light2.position.set(0, 100, 450);
  light2.lookAt(new THREE.Vector3(0, 0, 0));
  var anbientLight1 = new THREE.AmbientLight(0xffffff, 1);
  scene.add(anbientLight1);
  renderer.setClearColor(0x000000, 0);
  var devicePixelResio = window.devicePixelRatio;
  if (devicePixelResio > 2) {
    devicePixelResio = 2;
  }
  if (utils.dv != "pc") {
    devicePixelResio = 1;
  } else {
    devicePixelResio = 1;
  }
  //devicePixelResio=1;
  renderer.setPixelRatio(devicePixelResio);
  renderer.setClearColor(0xffffff);
  canvas = $(renderer.domElement);
  threeCanvasArea.append(canvas);
  makeBox();
  threeCanvasArea.bind("touchstart mousedown", _this.mousedownHl);
  threeCanvasArea.bind("touchmove mousemove", _this.mousemoveHl);
  threeCanvasArea.bind("touchend mouseup", _this.mouseupHl)
  this.threeCanvasArea = threeCanvasArea;
  this.renderer = renderer;
  this.scene = scene;
  this.stage = rotateStage;
  this.moveStage = moveStage;
  MAIN.scene = scene;
  MAIN.stage = this.stage;
  this.init = function () {
    initEnd = true;
    //console.log("init")
    resizeHl();
    this.startRender();
  }
  this.startRender = function () {
    threeCanvasArea.bind("touchstart mousedown", _this.mousedownHl);
    threeCanvasArea.bind("touchmove mousemove", _this.mousemoveHl);
    threeCanvasArea.bind("touchend mouseup", _this.mouseupHl);
    renderRoop();
  };
  /////////////////////////////
  //
  //mesh作成
  //
  ////////////////////////////
  var materialBox;
  var materialSphere;
  function makeBox() {
    var material1 = new THREE.MeshPhongMaterial({ color: 0xff0000, transparent: true, wireframe: true, side: THREE.DoubleSide, specular: 0xaaaaaa });
    //grometry->ポリゴンオブジェクト
    var geometry1 = new THREE.SphereGeometry(10, 32, 32)
    //mesh->テクスチャ付ポリゴン
    var mesh1 = new THREE.Mesh(geometry1, material1);
    materialBox = new THREE.MeshBasicMaterial({ color: 0x999999, wireframe: true, transparent: true, opacity: 0.2, side: THREE.DoubleSide, visible: true });
    materialSphere = new THREE.MeshBasicMaterial({ color: 0x000000, wireframe: true, transparent: true, opacity: 0.05, visible: true });
    var geometryBox = new THREE.BoxGeometry(50, 50, 50);
    geometryBox.computeBoundingSphere();
    var geometrySphere = new THREE.SphereGeometry(geometryBox.boundingSphere.radius, 8, 8);
    var sphere = new THREE.Mesh(geometrySphere, materialSphere);
    //mesh->テクスチャ付ポリゴン
    var box = new THREE.Mesh(geometryBox, materialBox);
    //シーンにmeshを設置
    //rotateStage.add(box);
    //rotateStage.add(sphere);
    moveStage.add(rotateStage);
    //moveStage.rotation.y=Math.PI*0.25;
    scene.add(moveStage);
  }
  var addResizeHlState;
  var addedResize;
  var winW, winH;
  this.addResizeHl = function (func) {
    addResizeHlState = true;
    addedResize = func;
  }
  function resizeHl() {
    //windowリサイズしたらサイズ変更
    winW = win.width();
    winH = win.height();
    if (winH < 480) {
      winH = 480;
    }
    if (initEnd) {
      canvasW = threeCanvasArea.width();
      canvasH = threeCanvasArea.height();
      if (canvasH < 480) {
        canvasH = 480
      }
      camera.aspect = canvasW / canvasH;
      //z位置が0でピクセル等倍になるようにカメラ位置セット
      setParmanentDistance();
      camera.updateProjectionMatrix();
      renderer.setSize(canvasW, canvasH);
      renderer.render(scene, camera);
      addedResize(winW, winH, canvasW, canvasH);
    }
  }
  var addUpdateState;
  var addedUpdate;
  this.addUpdateHl = function (func) {
    addUpdateState = true;
    addedUpdate = func;
  }
  this.update = function () {
    //renderRoop();
    if (initEnd) {
      if (inertialMoveEnabled) {
        inertialMove();
      } else if (!mousePressState) {
        removeStageQ();
      }
      if (addUpdateState) {
        addedUpdate();
      }
    }
  };
  ////////////////////////
  //
  //       mouse event
  //
  ///////////////////////
  var startP = new THREE.Vector2();
  var moveP = new THREE.Vector2();
  var difMoveP = new THREE.Vector2();
  var lastMoveP = new THREE.Vector2();
  var startEuler, moveEuler;
  var difEuler = new THREE.Euler();
  var mouseMoveCount = 0;
  var mouseMoveCountMax = 45;
  var mouseUpTimer;
  var mouseUpTimerEnabled = false;
  var mouseMoveIntervalCount = 0;
  var mouseMoveIntervalCountMax = 50;
  var lastEulerValue = new THREE.Vector3();
  var speedEulerValue = new THREE.Vector3();
  var startEulerValue, moveEulerValue;
  var hitCount = 0;
  var inertialSpeeds;
  var startQ = new THREE.Quaternion();
  var moveQ = new THREE.Quaternion();
  var mousePressState;
  var inertialMoveCount = 0;
  var inertialMoveCountMax = 25;
  var inertialMoveStartSpeed = new THREE.Vector3();
  var inertialMoveSpeed = new THREE.Vector3();
  var inertialMoveEuler = new THREE.Euler();
  var inertialMoveQ = new THREE.Quaternion();
  var inertialMoveEnabled;
  this.mousedownHl = function (e) {
    startP = getMousePoint(e);
    startEulerValue = getEulerValueFromMousePoint(startP);
    inertialSpeeds = [];
    inertialSpeeds = [];
    speedEulerValue.set(0, 0, 0);
    lastEulerValue.copy(startEulerValue);
    //rotateStageのquaternionを取得
    startQ.copy(rotateStage.quaternion);
    //以前の仕様と変更
    inertialMoveEnabled = false;
    mousePressState = true;
  }
  var tabletMouseMoveCount = 0;
  //ballがタッチしないと表示されない
  if (utils.dv != "pc") {
    var tabletMouseMove = setInterval(function () {
      //trace("touchmove")
      if (!initEnd) {
        return;
      }
      if (tabletMouseMoveCount < 1) {
        //trace("touchmove2")
        //console.log("強制touchmove")
        resizeHl();
        if (utils.dv == "tablet") {
          _this.mousemoveHl({ type: "mousemove", clientX: winH / 1.55, clientY: winW / 1.0 });
        } else {
          _this.mousedownHl({ type: "mousedown", clientX: 0, clientY: winH / 2.5 }); _this.mousemoveHl({ type: "mousemove", clientX: winW / 1.5, clientY: winH / 2.5 });
        }

      }
      tabletMouseMoveCount += 1;
      if (tabletMouseMoveCount > 2) {
        clearInterval(tabletMouseMove);
      }
    }, 200)
  }
  this.mousemoveHl = function (e) {
    moveP = getMousePoint(e);

    if (moveP.x == 0 && moveP.y == 0) {
      return;
    }
    moveEulerValue = getEulerValueFromMousePoint(moveP);
    //マウス操作を省いたので、コメントアウト
    /*if(mousePressState){
        //慣性モーメント用の値
        speedEulerValue.subVectors(moveEulerValue,lastEulerValue);
        lastEulerValue.copy(moveEulerValue);

        var moveRotationValue=moveEulerValue.sub(startEulerValue);

        inertialSpeeds.push(new THREE.Vector3().copy(speedEulerValue));
        if(inertialSpeeds.length>mouseMoveCountMax){
            inertialSpeeds.shift();
        }
        
        var euler=difEuler.setFromVector3(moveRotationValue);
       
        
        moveQ.setFromEuler(euler);
        //以前の仕様と変更
        rotateStage.quaternion.slerp(moveQ.multiply(startQ),1);
    }*/
    if (addedMouseMoveState) {
      addedMouseMove(moveP);
    }
  }
  this.mouseupHl = function (speed) {
    if (mousePressState) {
      var inertialSpeed = getAverageVector3(inertialSpeeds);
    }
    inertialMoveCount = 0;
    inertialMoveEnabled = true;
    mousePressState = false;
    if (inertialSpeed) {
      inertialMoveStartSpeed.copy(inertialSpeed);
    }
  }
  var addedMouseMove;
  var addedMouseMoveState;
  this.addMouseMoveHl = function (func) {
    addedMouseMove = func;
    addedMouseMoveState = true;
  }
  function inertialMove() {
    var inertialMoveResio = Math.pow(inertialMoveCount / inertialMoveCountMax, .3);
    if (inertialMoveResio > 1) {
      inertialMoveResio = 1;
      inertialMoveEnabled = false;
      removeStageQCount = 0;
    }
    inertialMoveSpeed.copy(inertialMoveStartSpeed).multiplyScalar(1 - inertialMoveResio);
    inertialMoveEuler.setFromVector3(inertialMoveSpeed);
    inertialMoveQ.setFromEuler(inertialMoveEuler);
    //以前の仕様と変更
    //moveStage.quaternion.multiply(inertialMoveQ);
    rotateStage.quaternion.multiply(inertialMoveQ);
    inertialMoveCount += 1;
  }
  var removeStageQCount = 0;
  var removeStageQCountMax = 100;
  var removeStageQTarget = new THREE.Quaternion();
  function removeStageQ() {
    var removeStageQResio = Math.pow(utils.getYoyoRatio2(removeStageQCount / removeStageQCountMax), 3);
    removeStageQResio = utils.getYoyoRatio(removeStageQCount / removeStageQCountMax);
    if (removeStageQResio > 1) {
      return;
    } else {
      //以前の仕様と変更
      //moveStage.quaternion.slerp(removeStageQTarget,removeStageQResio);
      rotateStage.quaternion.slerp(removeStageQTarget, removeStageQResio);
      removeStageQCount += 1;
    }
  }
  ////////////////////////
  //
  //       getMousePoint
  //
  ///////////////////////
  function getMousePoint(e) {
    var px = 0, py = 0;
    if (e.type == "mousedown" || e.type == "mousemove" || e.type == "click") {
      px = e.clientX;
      py = e.clientY;
    } else if (e.type == "touchstart" || e.type == "touchmove") {
      px = e.touches[0].pageX;
      py = e.touches[0].pageY;
    }
    //mousePointResio.x = ( px / MAIN.canvasW ) * 2 - 1;
    //mousePointResio.y = - ( py/ MAIN.canvasH ) * 2 + 1;
    return new THREE.Vector2(px, py)
  }
  function getEulerValueFromMousePoint(p) {
    var pressEulerValue = new THREE.Vector3();
    var xP = -(MAIN.canvasW / 2 - p.x) / (MAIN.canvasW / 2);
    pressEulerValue.y = Math.asin(xP);
    var yP = -((MAIN.canvasH) / 2 - p.y) / (MAIN.canvasH / 2);
    if (yP > 1) { yP = 1 };
    if (yP < -1) { yP = -1 };
    pressEulerValue.x = Math.asin(yP) * 0.5;
    return pressEulerValue;
  }
  function getAverageVector3(arry) {
    var sx = 0, sy = 0, sz = 0;
    for (var n = 0; n < arry.length; n++) {
      sx += arry[n].x;
      sy += arry[n].y;
      sz += arry[n].z;
      if (n == arry.length - 1) {
        sx /= arry.length;
        sy /= arry.length;
        sz /= arry.length;
      }
    }
    return new THREE.Vector3(sx, sy, sz);
  }
  /////////////////////////////
  //
  //フレームレート計測
  //
  ////////////////////////////
  var nowTime, lastTime
  var fsp;
  var totalTimes = [];
  var framedisplay;
  var keyTime = new Date().getTime();
  var updateLimit = 30;
  var renderCount = 0;
  nowTime = new Date().getTime();
  //フレームレート計測
  $(function () {
    //setFsp();
  })
  function setFsp() {
    framedisplay = $("<div id='framedisplay'></div>");
    framedisplay.css({
      "background-color": "black",
      "padding": "4px",
      "color": "white",
      "width": "2em",
      "position": "fixed",
      "right": "1em",
      "top": "0.2em",
      "height": "1em",
      "line-height": 1,
      "opacity": 0.2
    });
    $("body").append(framedisplay);
    lastTime = new Date().getTime();
    fsp = true;
  }
  function checkFsp() {
    if (renderCount % 10 == 0) {
      nowTime = new Date().getTime();
      var fpsNum = Math.floor(100000 / (nowTime - lastTime)) / 10;
      lastTime = nowTime;
    }
    framedisplay.text(fpsNum)
  }
  /////////////////////////////
  //
  //一定時間おきにレンダリング
  //
  ////////////////////////////
  function renderRoop() {
    requestAnimationFrame(renderRoop);
    nowTime = new Date().getTime();
    if (MAIN.scrollPositionState != "down" || MAIN.scrollmoving) {
      if (nowTime - keyTime > updateLimit) {
        keyTime = nowTime;
        //フレームレート計測
        if (fsp) { checkFsp(); }
        renderCount += 1;
        if (THREE.noRender) {
          return;
        }
        _this.update();
        renderer.render(scene, camera);
      }
    }
  }
  function setParmanentDistance() {
    //z位置が0でピクセル等倍になるようにカメラ位置セット
    var parmanentDistance = 1.025 * winH / Math.tan((camera.fov * Math.PI / 180));
    camera.position.set(0, 0, parmanentDistance);
  }
}
